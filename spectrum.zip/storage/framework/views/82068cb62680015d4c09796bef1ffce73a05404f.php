<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Spectrum</title>
      <!-- <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"> -->
      <!-- css -->
      <link href="<?php echo e(asset('assets/css/bootstrap.min')); ?>.css" rel="stylesheet" type="text/css">
      <link href="<?php echo e(asset('assets/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />
      <link href="<?php echo e(asset('assets/css/nivo-lightbox.css')); ?>" rel="stylesheet" />
      <link href="<?php echo e(asset('assets/css/nivo-lightbox-theme/default/default.css')); ?>" rel="stylesheet" type="text/css" />
      <link href="<?php echo e(asset('assets/css/animate.css')); ?>" rel="stylesheet" />
      <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
      <link href="<?php echo e(asset('assets/css/layout.css')); ?>" rel="stylesheet">
      <link href="<?php echo e(asset('assets/css/datepicker.css')); ?>" rel="stylesheet">
      <!-- template skin -->
      <!-- Fonts -->
      <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
      <!-- Styles -->
    </head>
    <body>
       <div class="" id="app">
            <App /> 
       </div>
    </body>
      <script src="<?php echo e(asset('js/app.js')); ?>"></script>
      <!-- Core JavaScript Files -->
      <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/jquery.easing.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/jquery.scrollTo.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/nivo-lightbox.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script> 
      <script src="<?php echo e(asset('assets/js/datepicker.js')); ?>"></script>
</html>
<?php /**PATH C:\xampp\htdocs\spectrum2\resources\views/welcome.blade.php ENDPATH**/ ?>
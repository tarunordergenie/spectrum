<template>
    <div class="">
            <div class="container">

    <h2>Politique De Confidentialité</h2>
    <p><strong>CTC Communications Corporation (CTC)</strong>a élaboré la présente Politique de confidentialité afin de démontrer notre ferme volonté d’expliquer en toute transparence quels renseignements nous recueillons par l’intermédiaire de ce site Web et comment nous les utilisons.</p>

    <h3>Collecte et diffusion de renseignements : principes généraux</h3>
    <p>Pendant que vous naviguez sur notre site Web, celui-ci recueille un fichier journal, l’adresse IP de votre ordinateur et d’autres données de suivi standard que nous utilisons pour évaluer la fréquentation et les habitudes d’utilisation du site Web. Ces données sont regroupées avec les données de suivi de tous les visiteurs du site Web. Nous utilisons ces renseignements pour personnaliser le site Web selon vos préférences, à partir des renseignements regroupés. Nous utilisons également ces renseignements pour évaluer les produits et services que nous pourrions vous proposer par la suite.</p>

    <p>Pour accéder à certaines sections de ce site Web, vous pourriez devoir fournir certains renseignements permettant de vous identifier tels que nom, titre, entreprise, adresse postale, adresse électronique et numéros de téléphone et de télécopieur (les « renseignements personnels »). Si vous remplissez un formulaire en ligne, toute information fournie dans une telle communication peut être recueillie en tant que renseignement personnel et être utilisée pour fournir le service que vous avez demandé. CTC restreint l’accès à vos renseignements personnels aux seuls employés de nos sociétés membres et de nos mandataires qui, à notre avis, ont besoin d’en prendre connaissance pour des raisons professionnelles légitimes en lien avec la réalisation de nos mandats ou avec les services que nous vous fournissons. Nous donnons de la formation aux employés afin de leur expliquer la signification de nos normes rigoureuses en matière de sécurité et de confidentialité des données et les exigences qui en découlent. Cependant, nous nous réservons en tout temps le droit, et vous consentez à ce droit, de protéger nos droits et nos biens y compris, sans limitation, le droit de transférer les données advenant un transfert de contrôle du site Web, ou en cas d’urgence, lorsque la sécurité est menacée.</p>

    <h3>Partage d’information</h3>
    <p>Sauf indication contraire dans la présente Politique de confidentialité, nous préserverons le caractère confidentiel de vos renseignements personnels et ne les divulguerons à aucun tiers, sauf si une telle divulgation est nécessaire pour:</p>
    <ol class="d">
        <li> nous conformer à une ordonnance d’un tribunal ou à une autre procédure judiciaire</li>
        <li> protéger nos droits ou nos biens</li>
        <li> faire respecter nos Conditions d’utilisation</li>
    </ol>
    <h3>Témoins</h3>
    <p>Un << témoin >> est un fichier contenant une petite quantité de données qui est envoyé par un site Web à l’ordinateur de l’utilisateur visitant le site, par l’intermédiaire de son navigateur, afin de permettre au site Web de retourner les résultats attendus par le navigateur. CTC utilise des témoins temporaires, ou témoins de session, pour faire en sorte que les visites sur son site Web s’effectuent de façon fluide et personnalisée en fonction du visiteur. Ces témoins nous permettent de transmettre au navigateur d’un visiteur des données adaptées aux préférences et aux besoins de ce dernier. CTC utilise également des témoins persistants, ou permanents, qui demeurent dans l’ordinateur d’un visiteur une fois que ce dernier a quitté le site Web.</p>

    <p>Si vous ne voulez pas que votre navigateur accepte les témoins, vous pouvez désactiver l’option d’acceptation des témoins dans les paramètres de configuration de votre navigateur. Toutefois, le fait de désactiver la fonction de prise en charge des témoins du navigateur empêchera notre site Web de fonctionner normalement, ce qui pourrait vous priver de la possibilité d’utiliser pleinement l’ensemble des fonctionnalités et des données du site Web.</p>

    <h3>Notification des changements</h3>
    <p>CTC se réserve le droit, en tout temps et sans préavis, de procéder à des ajouts, des mises à jour et des modifications de la présente Politique de confidentialité en publiant simplement de tels ajouts, mises à jour et modifications sur le site Web. Tout ajout, modification ou mise à jour ainsi effectué prendra immédiatement effet dès sa publication sur le site Web.</p>
    
    <h3>Droits d’auteur</h3>
    <p>Le contenu de ce site Web, y compris, sans s’y limiter, le texte et les images qui y apparaissent et leur disposition, est protégé par les droits d’auteur de CTC Communications Corporation (2019). Tous droits réservés. Toute utilisation de ce contenu à quelque fin que ce soit est interdite sans l’autorisation écrite préalable de CTC.</p>

    <h3>Exclusion de responsabilité</h3>
    <p>L’utilisateur assume l’entière responsabilité de l’utilisation de ce site Web. Toute l’information envoyée à ce site Web est sécurisée dans la mesure permise par la technologie existante. Cependant, vous ne devez pas oublier que la sécurité et l’absence d’erreur d’une transmission par Internet ne peuvent jamais être entièrement garanties. En particulier, comme les courriels envoyés à ce site Web ou à partir de celui-ci pourraient ne pas être sécurisés, vous devez accorder une attention particulière au choix de l’information que vous nous envoyez par ce moyen. De plus, il vous incombe de protéger tout mot de passe, code d’identification ou autre processus d’accès particulier utilisé sur ce site Web.</p>

    <p>CTC ne donne aucune garantie et ne fait aucune déclaration quant à l’exactitude ou au caractère suffisant de l’information publiée sur ce site Web. CTC ou l’une ou l’autre des personnes participant à la création ou à la gestion de ce site Web ne sauraient en aucune circonstance, y compris pour négligence, être tenues responsables des dommages directs, indirects, particuliers, accessoires ou consécutifs ou des pertes de bénéfices résultant de l’utilisation ou de l’impossibilité de l’utilisation de ce site Web ou de tout autre site Web lié à celui-ci. Ces circonstances comprennent, sans s’y limiter, la confiance accordée par un membre ou un visiteur à une information obtenue à partir du site Web et les problèmes ayant pour origine une faute, la suppression de fichiers, une erreur, une omission, une interruption, un virus, un défaut, un mauvais fonctionnement, le vol, un problème de communication, la destruction ou l’accès non autorisé.</p>

    <p>Les liens vers d’autres sites Web sont présentés par simple courtoisie. CTC n’assume aucune responsabilité quant au contenu ou à l’exactitude de tels sites Web.</p>

    <p>CTC veille dans une mesure raisonnable à ce que le contenu des bases de données demeure à jour et exact; toutefois, l’exactitude, l’exhaustivité et l’actualité de cette information ne peuvent être garanties. Par conséquent, CTC ne saurait être tenue responsable des décisions et des mesures prises en se fondant sur l’une ou l’autre des bases de données du site Web.</p>

    <h3>Avertissement : Indications non approuvées</h3>
    <p>CTC ne recommande l’utilisation d’aucun agent en dehors de ses indications approuvées. Veuillez vous reporter aux renseignements thérapeutiques approuvés pour chaque produit afin de prendre connaissance des indications approuvées, des contre-indications et des mises en garde.</p>

    <p>Les participants ont la responsabilité implicite d’utiliser l’information nouvellement obtenue dans le but d’améliorer les résultats pour le patient et leur propre perfectionnement professionnel. L’information présentée dans le cadre de cette activité n’est pas destinée à servir de ligne directrice pour la prise en charge des patients.</p>

    <p>Avant d’utiliser les procédures, médicaments ou autres méthodes diagnostiques ou thérapeutiques abordés ou suggérés dans le cadre de l’activité, le clinicien doit impérativement évaluer l’état de son patient et les contre-indications ou risques possibles de leur utilisation, prendre connaissance de toute information pertinente sur le produit fournie par le fabricant et la comparer avec les recommandations des autres autorités.</p>

    <h3>Votre acceptation des présentes modalités</h3>
    <p>En utilisant notre site Web, nos produits ou nos services, vous signifiez votre acceptation des modalités de la Politique de confidentialité de CTC. Chaque fois que vous fournissez des renseignements par ce site Web, vous consentez à la collecte, à l’utilisation et à la divulgation de ces renseignements conformément à cette Politique de confidentialité. Si vous n’acceptez pas ces modalités, veuillez vous abstenir d’utiliser le site Web, nos produits ou nos services.</p>

    <h3>Prise en compte de vos préoccupations</h3>
    <p>Si vous avez des questions, des préoccupations ou des problèmes au sujet de notre Politique de confidentialité, ou pour nous demander des renseignements, veuillez communiquer avec nous par écrit au numéro de télécopieur (905) 712-2935, à l’attention du : Responsable en chef de la protection de la vie privée.</p>

</div>
    </div>
</template>
<script>
export default {
    
}
</script>
<style scoped>

 h1, h2, h3, h4, h5, h6 {
    font-family: 'Lato', sans-serif;
    font-weight: 600;
    color: rgb(24, 24, 24);
    line-height: 1.1em;
    }
    ol.d {list-style-type: lower-alpha;}
</style>
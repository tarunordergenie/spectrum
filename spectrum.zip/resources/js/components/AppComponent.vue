<template>
<div class="app">
    <body id="page-top" data-spy="scroll" data-target=".navbar-custom">
        <div id="wrapper">
            <router-view></router-view>
        </div>
    </body>
</div>
</template>
<script>
    export default {
        mounted() {

        },
        components: {
            
        }
    }
</script>

<template>
<div class="">
<div class="container">

    <h2>Privacy Policy</h2>
    <p><strong>CTC Communications Corporation (CTC)</strong> has created this Privacy Policy to demonstrate our firm commitment to fully disclosing what information we collect via this website and how we use it.</p>

    <h3>Information Collection and Dissemination: General Principles</h3>
    <p>As you browse our website, it collects a log file, the IP address of your computer, and other standard tracking data we use to evaluate website traffic and usage patterns. Such information is aggregated with tracking data from all website visitors. We will use the information to personalize the website according to your preferences, based on the aggregated information. We also use this information to evaluate products and services we may offer you in future.</p>

    <p>Some portions of this website may require you to give us personally identifiable information such as your name, job title, company, physical mailing address, email address, and telephone and fax numbers (Personal Information). If you complete online forms, any information provided in such communications may be collected as Personal Information and used to deliver the service you requested. CTC restricts access to your Personal Information to those employees of our member companies and our agents whom we determine have a legitimate business purpose to access such information in connection with the carrying-out of our engagements or provision of services to you. We provide training to educate employees about the meaning and requirements of our strict standards for data security and confidentiality. At all times, however, we reserve the right, and you consent to such right, to protect our rights and property including, without limitation, the right to transfer the data in the event of a transfer of control of the website, or during emergencies when safety is at risk.</p>

    <h3>Information Sharing</h3>
    <p>Except as otherwise provided in this privacy policy, we will keep your Personal Information private and will not share it with third parties, unless such disclosure is necessary to:</p>
    <ol class="d">
        <li> Comply with a court order or other legal process</li>
        <li> Protect our rights or property</li>
        <li> Enforce our terms of service</li>
    </ol>
    <h3>Cookies</h3>
    <p>A "cookie" is a bit of data sent by a website through the browser to the computer of the user visiting the website and enables the website to return the results the browser expects. CTC uses temporary, session-specific cookies to ensure visits to its website are smooth and customized for the visitor. Such cookies allow us to provide a visitor's browser with information tailored to the visitor's preferences and needs. CTC also uses permanent or persistent cookies that remain on a visitor's computer after the visitor leaves the website.</p>

    <p>If you do not want your browser to accept cookies, you can turn off the cookie acceptance option in the browser's settings. However, disabling the cookie support function of the browser will prevent our website from functioning properly and you may not be able to fully utilize all of the website's features and information.</p>

    <h3>Notification of Changes</h3>
    <p>CTC reserves the right, at any time and without notice, to add to, change, update, or modify this Privacy and Legal Policy simply by posting such change, update, or modification on the website. Any such change, update, or modification will be effective immediately upon posting on the website.</p>
    
    <h3>Copyright</h3>
    <p>The content of this website including but not limited to the text and images herein and their arrangements are copyright 2009 CTC Communications Corporation. All Rights Reserved. Use of this information for any purpose is prohibited without the prior written permission of CTC.</p>

    <h3>Disclaimer of Liability</h3>
    <p>The user assumes all responsibility for the use of this website. All information transmitted to this website is secure to the extent possible using existing technology. You should keep in mind, however, that no Internet transmission is ever 100% secure or error-free. In particular, email sent to or from this website may not be secure, and you should therefore take special care in deciding what information you send to us via email. Moreover, where you use passwords, identification (ID) numbers, or other special access features on this website, it is your responsibility to safeguard them.</p>

    <p>CTC makes no warranty, guarantee, or representation as to the accuracy or sufficiency of the information posted herein. Under no circumstances, including negligence, shall CTC or anyone else involved in creating or maintaining this website be liable for any direct, indirect, special, or incidental/consequential damages or lost profits that result from the use or inability to use this website and/or any other websites that are linked to this website. These include but are not limited to reliance by a member or visitor on any information obtained via the website, or problems that result from mistakes, deletion of files, errors, omissions, interruptions, viruses, defects, failure of performance, theft, communications failure, destruction, or unauthorized access.</p>

    <p>Links connecting this website with other websites are provided as a courtesy only. CTC assumes no responsibility or liability for other such sites' content or accuracy.</p>

    <p>CTC makes a reasonable effort to keep the database up-to-date and accurate; however, accuracy, completeness, and timeliness of the information cannot be guaranteed. Thus, CTC shall not be liable for decisions and actions taken based on the databases on this website.</p>

    <h3>Disclaimer: Unlabeled Indications</h3>
    <p>CTC does not recommend the use of any agent outside of the labeled indications. Please refer to the official prescribing information for each product for discussion of approved indications, contraindications, and warnings.</p>

    <p>Participants have an implied responsibility to use newly acquired information to enhance patient outcomes and their own professional development. The information presented in this activity is not intended to serve as a guideline for patient management.</p>

    <p>Any procedures, medications, or other courses of diagnosis or treatment discussed or suggested in the activity should only be used by clinicians based on the evaluation of their patients' conditions and possible contraindications or dangers in use, review of any applicable manufacturer's product information, and comparison with recommendations of other authorities.</p>

    <h3>Your Acceptance of These Terms</h3>
    <p>By using our website, products, or services, you signify your acceptance of the terms of the CTC Privacy Policy. Whenever you submit information via this website, you consent to the collection, use, and disclosure of that information in accordance with this Internet Privacy and Legal Statement. If you do not agree to the above terms, please do not use the website, products, and/or services.</p>

    <h3>Addressing Your Concerns</h3>
    <p>If you have questions, concerns, or problems regarding our Privacy Policy, or to request information from us, please contact us in writing<strong> via fax at (905) 712-2935, attention: Chief Privacy Officer.</strong></p>

</div>

        

</div>  
        
</template>
<script>
export default {
    
}
</script>
<style scoped>
 h1, h2, h3, h4, h5, h6 {
    font-family: 'Lato', sans-serif;
    font-weight: 600;
    color: rgb(24, 24, 24);
    line-height: 1.1em;
    }
    ol.d {list-style-type: lower-alpha;}
    
</style>
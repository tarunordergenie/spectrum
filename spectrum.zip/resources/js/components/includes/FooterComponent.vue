<template>
    <div class="footer">
            <footer>
               <div class="sub-footer">
                  <div class="container-fluid">
                     <div class="row">
                        <div class="col-sm-12">
                           <div class="wow fadeInLeft" data-wow-delay="0.1s">
                              <div class="text-left">
                                 <p>© 2020 CTC Communications All rights reserved.</p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </footer>
    </div>
</template>
<script>
export default {
    
}
</script>
<style scoped>

</style>